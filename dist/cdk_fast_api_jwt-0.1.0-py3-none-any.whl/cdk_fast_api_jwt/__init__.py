"""
.. include:: ../README.md
"""
# The above makes the README part of the documentation.
